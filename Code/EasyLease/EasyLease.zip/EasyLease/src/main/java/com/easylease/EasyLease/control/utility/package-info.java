/**
 * Domain classes used for Utility Class.
 * <p>
 * These classes support the functionality of the other classes.
 * </p>
 *
 * @since 0.1
 * @author Antonio Sarro
 * @version 0.1
 */
package com.easylease.EasyLease.control.utility;